import { describe, expect, it, vi } from 'vitest';
import { decide, decideForWindow, getAnswer, ruleMatches } from '../../src/engine/decide';
import { ANSWERS, RULES, answerById } from '../../src/engine/content';
import { LABELS, type Label, type PlotSummary, type SeasonWindow } from '../../src/engine/types';

const WINDOWS: SeasonWindow[] = ['pre_short_rains', 'short_rains', 'pre_long_rains', 'long_rains', 'dry'];

function summary(p: Partial<PlotSummary> & { dominant: Label | 'none' }): PlotSummary {
  const counts = Object.fromEntries(LABELS.map((l) => [l, 0])) as Record<Label, number>;
  return { n: 10, counts, uncertain: 0, affected: 0, distinctProblems: 0, ...p };
}

describe('content', () => {
  it('every rule points at an answer that exists', () => {
    for (const r of RULES) expect(answerById(r.then), r.then).toBeDefined();
  });
  it('last rule is the empty ask_officer catch-all', () => {
    const last = RULES[RULES.length - 1];
    expect(last.if).toEqual({});
    expect(last.then).toBe('ask_officer');
    expect(answerById('ask_officer')?.severity).toBe('ask');
  });
  it('answer ids are unique', () => {
    expect(new Set(ANSWERS.map((a) => a.id)).size).toBe(ANSWERS.length);
  });
});

describe('getAnswer', () => {
  it('maps answers.json fields onto AnswerCard', () => {
    const c = getAnswer('rust_high_pre_rains');
    const raw = answerById('rust_high_pre_rains')!;
    expect(c.id).toBe('rust_high_pre_rains');
    expect(c.severity).toBe(raw.severity);
    expect(c.text).toEqual(raw.text);
    expect(c.notSure).toEqual(raw.not_sure);
    expect(c.sources).toEqual(raw.sources);
    expect(c.assumption).toBe(raw.assumption);
    expect(c.kind).toBe(raw.kind);
    expect(c.reviewStatus).toEqual(raw.review_status);
    for (const lang of Object.keys(raw.text)) {
      expect(c.audio[lang as keyof typeof c.audio]).toBe(`/audio/${lang}/rust_high_pre_rains.mp3`);
    }
    expect(Object.keys(c.audio).sort()).toEqual(Object.keys(raw.text).sort());
  });
  it('unknown id returns the ask_officer card', () => {
    expect(getAnswer('no_such_card').id).toBe('ask_officer');
    expect(getAnswer('').severity).toBe('ask');
  });
});

describe('ruleMatches', () => {
  const s = summary({ dominant: 'rust', affected: 4, distinctProblems: 1 });
  it('an unknown condition key makes the rule not match', () => {
    expect(ruleMatches({ dominant: 'rust', colour: 'red' } as never, s, 'dry')).toBe(false);
  });
  it('a non-numeric threshold makes the rule not match', () => {
    expect(ruleMatches({ affected_gte: '3' } as never, s, 'dry')).toBe(false);
  });
  it('an empty condition always matches', () => {
    expect(ruleMatches({}, s, 'dry')).toBe(true);
  });
});

describe('decideForWindow', () => {
  it('rust 3+ follows the season', () => {
    const s = summary({ dominant: 'rust', affected: 3, distinctProblems: 1 });
    expect(decideForWindow(s, 'pre_short_rains').id).toBe('rust_high_pre_rains');
    expect(decideForWindow(s, 'pre_long_rains').id).toBe('rust_high_pre_rains');
    expect(decideForWindow(s, 'short_rains').id).toBe('rust_high_in_rains');
    expect(decideForWindow(s, 'long_rains').id).toBe('rust_high_in_rains');
    expect(decideForWindow(s, 'dry').id).toBe('rust_high_dry');
  });
  it('first match wins: unsure before everything', () => {
    const s = summary({ dominant: 'rust', affected: 5, uncertain: 3, distinctProblems: 2 });
    expect(decideForWindow(s, 'pre_short_rains').id).toBe('too_many_unsure');
  });
  it('healthy and none', () => {
    expect(decideForWindow(summary({ dominant: 'healthy' }), 'dry').id).toBe('healthy_all');
    expect(decideForWindow(summary({ dominant: 'none' }), 'dry').id).toBe('ask_officer');
  });
  it('not_leaf majority', () => {
    expect(decideForWindow(summary({ dominant: 'not_leaf', uncertain: 2 }), 'dry').id).toBe('not_a_leaf');
  });
  it('is pure: same input, same output', () => {
    const s = summary({ dominant: 'phoma', affected: 2, distinctProblems: 1 });
    expect(decideForWindow(s, 'dry')).toEqual(decideForWindow(s, 'dry'));
  });
});

describe('decide', () => {
  it('uses the season window of the date', () => {
    const s = summary({ dominant: 'rust', affected: 6, distinctProblems: 1 });
    expect(decide(s, new Date(2026, 9, 4, 12)).id).toBe('rust_high_pre_rains');
    expect(decide(s, new Date(2026, 11, 1, 12)).id).toBe('rust_high_in_rains');
    expect(decide(s, new Date(2027, 0, 10, 12)).id).toBe('rust_high_dry');
  });
  it('does not read the clock', () => {
    const now = vi.spyOn(Date, 'now');
    decide(summary({ dominant: 'healthy' }), new Date(2026, 9, 4, 12));
    expect(now).not.toHaveBeenCalled();
    now.mockRestore();
  });
});

// Safety invariants mirrored from app/qa/checks/decision_matrix.py.
function* reachableSummaries(): Generator<[PlotSummary, SeasonWindow]> {
  for (const dominant of [...LABELS, 'none'] as (Label | 'none')[])
    for (let affected = 0; affected <= 10; affected++)
      for (let uncertain = 0; uncertain + affected <= 10; uncertain++)
        for (const distinct of [1, 2, 3]) {
          const noDisease = dominant === 'healthy' || dominant === 'none';
          if (noDisease ? affected > 0 : affected === 0) continue;
          if (distinct > Math.max(1, affected)) continue;
          for (const window of WINDOWS) yield [summary({ dominant, affected, uncertain, distinctProblems: distinct }), window];
        }
}

describe('safety invariants over every reachable summary', () => {
  it('hold for all summaries', () => {
    const sev = (id: string) => answerById(id)?.severity ?? 'missing';
    const bad: string[] = [];
    let seen = 0;
    for (const [s, window] of reachableSummaries()) {
      seen++;
      const card = decideForWindow(s, window);
      const cs = sev(card.id);
      const key = `${s.dominant} a=${s.affected} u=${s.uncertain} d=${s.distinctProblems} ${window} -> ${card.id}`;
      if (cs === 'missing') bad.push('missing ' + key);
      if (s.uncertain >= 3 && cs !== 'ask') bad.push('unsure>=3 not ask ' + key);
      if (s.dominant === 'not_leaf' && card.id !== 'not_a_leaf' && cs !== 'ask') bad.push('not_leaf ' + key);
      if (s.distinctProblems >= 2 && card.id !== 'mixed_problems' && cs !== 'ask') bad.push('mixed ' + key);
      if (s.affected <= 1 && cs === 'act') bad.push('act on <=1 ' + key);
      if (card.id === 'healthy_all' && s.affected > 0) bad.push('healthy_all affected ' + key);
    }
    expect(seen).toBe(3510);
    expect(bad).toEqual([]);
  });
});
