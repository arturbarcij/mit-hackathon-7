// Short UI labels (button words, tile words). Every instruction sentence comes from
// answers.json through the engine; only these few labels live here.
// Swahili labels are a builder draft, not reviewed by a native speaker (see README_DEPLOY.md).
// Kikuyu labels are not written yet: Kikuyu falls back to Swahili and the screen shows the
// "not translated yet" tag.
import { getAnswer, type AnswerCard, type Lang } from '../engine';

export const LANGS: readonly Lang[] = ['sw', 'kik', 'en'];

type Key =
  | 'next'
  | 'yes'
  | 'no'
  | 'take_photo'
  | 'upload'
  | 'sample'
  | 'retake'
  | 'skip'
  | 'done'
  | 'of'
  | 'leaves'
  | 'rust'
  | 'no_problem'
  | 'other_spots'
  | 'not_sure'
  | 'act'
  | 'wait'
  | 'ask'
  | 'send_sms'
  | 'history'
  | 'new_check'
  | 'start_again'
  | 'mock'
  | 'offline_ready'
  | 'offline_not_ready'
  | 'not_translated'
  | 'machine_draft'
  | 'photos_ok'
  | 'to_retake'
  | 'checking'
  | 'chars'
  | 'demo_number'
  | 'assumption'
  | 'sources'
  | 'no_checks'
  | 'credits'
  | 'sample_note'
  | 'back';

const EN: Record<Key, string> = {
  next: 'Next',
  yes: 'Yes',
  no: 'No',
  take_photo: 'Take photo',
  upload: 'Choose photo',
  sample: 'Try a sample plot',
  retake: 'Take again',
  skip: 'Skip this photo',
  done: 'See result',
  of: 'of',
  leaves: 'leaves',
  rust: 'Rust',
  no_problem: 'No problem seen',
  other_spots: 'Other spots: ask the officer',
  not_sure: 'Not sure',
  act: 'I will act',
  wait: 'I will wait',
  ask: 'Ask the officer',
  send_sms: 'Send SMS',
  history: 'History',
  new_check: 'New check',
  start_again: 'Start again',
  mock: 'MOCK MODEL: results are not real',
  offline_ready: 'Works offline',
  offline_not_ready: 'Saving for offline use',
  not_translated: 'Not translated yet',
  machine_draft: 'Machine translation, pending review',
  photos_ok: 'photos OK',
  to_retake: 'Take again',
  checking: 'Checking',
  chars: 'characters',
  demo_number: 'Demo number, not a real cooperative line',
  assumption: 'Assumption',
  sources: 'Sources',
  no_checks: 'No checks yet',
  credits: 'Photo credits',
  sample_note: 'Sample photos from public sources, not from Kenya. Labels not checked by an agronomist.',
  back: 'Back',
};

// Builder draft, pending native review.
const SW: Partial<Record<Key, string>> = {
  next: 'Endelea',
  yes: 'Ndiyo',
  no: 'Hapana',
  take_photo: 'Piga picha',
  upload: 'Chagua picha',
  sample: 'Jaribu shamba la mfano',
  retake: 'Piga tena',
  skip: 'Ruka picha hii',
  done: 'Ona jibu',
  of: 'kati ya',
  leaves: 'majani',
  rust: 'Kutu',
  no_problem: 'Hakuna tatizo',
  other_spots: 'Madoa mengine: muulize afisa',
  not_sure: 'Hatuna uhakika',
  act: 'Nitachukua hatua',
  wait: 'Nitasubiri',
  ask: 'Muulize afisa',
  send_sms: 'Tuma SMS',
  history: 'Historia',
  new_check: 'Ukaguzi mpya',
  start_again: 'Anza tena',
};

export function t(key: Key, lang: Lang): string {
  if (lang === 'en') return EN[key];
  return SW[key] ?? EN[key];
}

export interface CardText {
  text: string;
  notSure: string | null;
  /** Language actually shown. */
  shown: Lang;
  /** Tag to show under the text when it is not in the chosen language or is a machine draft. */
  tag: string | null;
}

/** Text of an answer card in the chosen language, falling back to Swahili, then English. */
export function cardText(card: AnswerCard, lang: Lang): CardText {
  const order: Lang[] = lang === 'en' ? ['en', 'sw'] : lang === 'sw' ? ['sw', 'en'] : ['kik', 'sw', 'en'];
  const shown = order.find((l) => card.text[l]) ?? 'en';
  const text = card.text[shown] ?? '';
  const notSure = card.notSure?.[shown] ?? card.notSure?.en ?? null;
  let tag: string | null = null;
  if (shown !== lang) tag = t('not_translated', 'en');
  else if (/machine/.test(card.reviewStatus?.[shown] ?? '')) tag = t('machine_draft', 'en');
  return { text, notSure, shown, tag };
}

/** The card if answers.json has it, else null (getAnswer falls back to ask_officer). */
export function cardIfExists(id: string): AnswerCard | null {
  const c = getAnswer(id);
  return c.id === id ? c : null;
}

/** Name of each language in its own words, from answers.json language_name. */
export function languageName(lang: Lang): string {
  const c = cardIfExists('language_name');
  return c?.text[lang] ?? { sw: 'Kiswahili', kik: 'Gikuyu', en: 'English' }[lang];
}
