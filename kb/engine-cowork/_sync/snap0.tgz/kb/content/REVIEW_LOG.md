# Content review log

Owner: content-voice. Updated Sat 3 Oct 2026, late evening. Nothing here has been reviewed by a native speaker yet.

## Summary

- 28 answers in `app/src/content/answers.json`. All have English and Swahili text. 8 core answers have Kikuyu text.
- Swahili status is `draft` for every entry. Drafted by Claude. The Gemini cross-check from the brief has **not been run**, so no entry is `cross_checked`.
- Kikuyu status is `machine_draft_pending_native_review`. The NLLB-200 pass from the brief was **not run** (no `transformers` on this machine). The Kikuyu lines were drafted by Claude directly. **Confidence in Kikuyu quality is low.** Sentences are kept very short on purpose. Treat them as a placeholder that shows the pipeline, not as correct Gĩkũyũ. The UI must show the "pending native review" label.
- No audio has been rendered. This log has no audio column to tick yet.
- Rules (`rules.json`) reviewed. Every numeric threshold carries `assumption: true` with "officer to confirm". The catch-all is `ask_officer`. No change needed.

## Changes made in the Sat night review

- Result cards cut to two sentences where possible (rust cards, cercospora, phoma, leaf miner).
- Added a "not sure" line to `mixed_problems`, `too_many_unsure`, `ask_officer`, and to the Kikuyu versions of `healthy_all` and `rust_high_pre_rains`.
- `cercospora`: dropped "worse on hungry or stressed trees". The only source is non-Kenyan (S18) and the sources disagree on shade. Treatment stays "ask the officer".
- `miner`: Swahili now says "viwavi wachimbaji wa majani" (caterpillars that mine leaves). The glossary found no Swahili term for leaf miner, so this is a descriptive phrase. Keeps the safety line against spraying on your own (S17).
- `decision_act`: no longer assumes the problem is rust. It says to ask the cooperative or officer what to do, and gives protective gear advice only "if you spray" (S20). This avoids contradicting the leaf miner card.
- `healthy_all`: marked as an assumption (it depends on the unsure-leaf cut-off).
- Swahili wording made consistent: "afisa wa kilimo" (officer), "chama cha ushirika" (cooperative), "dawa ya shaba" (copper), "kutu" (rust), "kupogoa" (prune), "kupalilia" (weed).
- Checked: no doses, no brands, no shade advice, no percentage thresholds stated as fact, no spray advice for phoma or leaf miner.

## Answer status

| Answer ID | Kind | Severity | Swahili | Kikuyu | Basis | Audio |
|---|---|---|---|---|---|---|
| how_to_pick_leaves | guidance | ok | draft | machine_draft_pending_native_review | sourced | audio: not rendered |
| how_to_photograph | guidance | ok | draft | n/a | plain | audio: not rendered |
| retake_blurry | guidance | watch | draft | n/a | plain | audio: not rendered |
| retake_dark | guidance | watch | draft | n/a | plain | audio: not rendered |
| not_a_leaf | guidance | watch | draft | n/a | plain | audio: not rendered |
| healthy_all | result | ok | draft | machine_draft_pending_native_review | assumption | audio: not rendered |
| rust_low | result | watch | draft | n/a | assumption | audio: not rendered |
| rust_high_pre_rains | result | act | draft | machine_draft_pending_native_review | assumption | audio: not rendered |
| rust_high_in_rains | result | act | draft | n/a | assumption | audio: not rendered |
| rust_high_dry | result | watch | draft | n/a | assumption | audio: not rendered |
| cercospora | result | ask | draft | n/a | sourced | audio: not rendered |
| phoma | result | ask | draft | n/a | sourced | audio: not rendered |
| miner | result | ask | draft | n/a | sourced | audio: not rendered |
| mixed_problems | result | ask | draft | n/a | assumption | audio: not rendered |
| too_many_unsure | result | ask | draft | machine_draft_pending_native_review | assumption | audio: not rendered |
| ask_officer | result | ask | draft | machine_draft_pending_native_review | assumption | audio: not rendered |
| berries_out_of_scope | guidance | ask | draft | n/a | sourced | audio: not rendered |
| other_crop | guidance | watch | draft | n/a | plain | audio: not rendered |
| consent_main | flow | ok | draft | n/a | plain | audio: not rendered |
| consent_photos | flow | ok | draft | n/a | plain | audio: not rendered |
| decision_act | flow | ok | draft | machine_draft_pending_native_review | sourced | audio: not rendered |
| decision_wait | flow | ok | draft | machine_draft_pending_native_review | plain | audio: not rendered |
| decision_ask | flow | ok | draft | machine_draft_pending_native_review | plain | audio: not rendered |
| referral_ready | flow | ok | draft | n/a | plain | audio: not rendered |
| language_name | flow | ok | draft | n/a | plain | audio: not rendered |
| nudge_leaf_check | nudge | ok | draft | n/a | plain | audio: not rendered |
| nudge_weather_everyone | nudge | ok | draft | n/a | plain | audio: not rendered |
| nudge_officer_visit | nudge | ok | draft | n/a | plain | audio: not rendered |

Swahili status scale: `draft`, `cross_checked`, `human_reviewed`. Kikuyu: `machine_draft_pending_native_review`, then `human_reviewed`.

## Kikuyu drafts (all pending native review)

- `how_to_pick_leaves`: Oya mathangũ 10 kuuma mĩhari ĩrĩa mĩũru makĩria. Mahaandĩke karatasi-inĩ, mũthia wa thĩ ũrorete igũrũ.
- `healthy_all`: Gũtirĩ thĩna wonekete mathangũ-inĩ marĩa. Thiĩ na mbere kũrora, makĩria thutha wa mbura.
- `rust_high_pre_rains`: Mathangũ maingĩ marĩ na kutu, na mbura ĩrĩ hakuhĩ. Ũria kooperatĩvu dawa ya copper na ũigana wayo.
- `too_many_unsure`: Tũtiramenya mathangũ maingĩ. Ũria mũrũgamĩrĩri wa ũrĩmi, kana ũhũre picha ingĩ mũthenya.
- `ask_officer`: Tũtingĩhota gũkuuga wega ũhoro wa mathangũ maya. Ũria mũrũgamĩrĩri wa ũrĩmi.
- `decision_act`: Wacagua gũthondeka. Ũria kooperatĩvu kana mũrũgamĩrĩri ũrĩa ũgwĩka. Ũngĩkunyũrũria, ĩhumbe gloves, buti na nguo ya moko marũku, na ũthambe thutha.
- `decision_wait`: Wacagua gũtegereza. Rora rĩngĩ wikendi ĩrĩa ĩkoka.
- `decision_ask`: Wacagua kũria mũrũgamĩrĩri wa ũrĩmi. Ũhoro waku ũrĩ mũhaano wa gũtũmwo.

Terms the reviewer must supply or confirm: kutu (rust, a Swahili loan here), "mũrũgamĩrĩri wa ũrĩmi" (agriculture officer, guessed), kooperatĩvu (cooperative, loan), copper, picha (photo, Swahili loan), gloves and buti (loans), "nguo ya moko marũku" (long sleeves, guessed). Timing detail ("just before the rains, again after three weeks") is left out of the Kikuyu rust card to keep it short; the Swahili and English cards carry it.
Licence note: Meta MMS-TTS and NLLB are CC-BY-NC-4.0 (non-commercial). Say so in LANGUAGES.md.

## Swahili review checklist (10 minutes, Sunday morning)

Reviewer: a Kenyan Swahili speaker, ideally from central Kenya. Read the English line, then the Swahili line, and mark each answer OK or write a fix. Score 1 to 5 for "would a farmer understand this when listening".

1. **Kenyan, not Tanzanian.** The only coffee Swahili we found is from Tanzania. Say if any word sounds Tanzanian or too formal for Kenya.
2. **Key terms.** Confirm or replace each:
   - kutu (coffee leaf rust)
   - dawa ya shaba (copper spray). Tanzanian sources say "mrututu"; we avoided it.
   - kunyunyiza (to spray) and kupogoa (to prune)
   - afisa wa kilimo (agriculture officer). Alternative: afisa wa ugani.
   - chama cha ushirika (cooperative)
   - mvua inakaribia (rains are close), wikendi (weekend)
3. **Words with no source.** These are our own wording and need a real check:
   - `miner`: "viwavi wachimbaji wa majani" (leaf miner). Is there a better farmer word?
   - `phoma`: "madoa meusi ya mviringo ... Phoma". Does a farmer need the name Phoma at all?
   - `cercospora`: "ugonjwa wa madoa ya kahawia" (brown eye spot).
   - "nyigu wasaidizi" (helpful wasps) and "nondo" (moths) in the leaf miner card.
   - "Chuma majani" (pick leaves) in `how_to_pick_leaves`.
   - Protective gear in `decision_act`: glavu, buti, nguo za mikono mirefu.
4. **Safety.** Confirm that no line tells the farmer to spray without asking, that `miner` clearly says not to spray alone, and that no line names a product or amount.
5. **Tone.** Polite "wewe" form, no jargon, each line under about 12 seconds when read aloud.
6. **SMS nudges.** Three nudges, each under 160 characters. Check they read naturally as a text message.
7. **Consent lines** (`consent_main`, `consent_photos`): is it clear that nothing is sent unless the farmer presses send, and that saying no is allowed?
8. **Sign-off.** Name, date, and whether the Swahili is fit to record. Set `reviewed_by` and `review_status.sw` to `human_reviewed` in `answers.json` for each checked entry.

Fixes go back to content-voice. Any changed line needs its audio re-rendered (the render script skips unchanged text by hash).

## Kikuyu reviewer checklist (if a native speaker is available)

Same sheet, 8 core entries only. First question: is this understandable at all? If most lines need rewriting, drop the Kikuyu audio from the demo or play one clip and say plainly it is a machine draft.
