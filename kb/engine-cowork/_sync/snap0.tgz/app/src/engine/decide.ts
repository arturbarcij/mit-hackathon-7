// Rule-based decision. Pure: no randomness, no clock. Every word the farmer sees
// comes from answers.json; this module only picks an id. Fail safe to ask_officer.
import { RULES, answerById } from './content';
import { seasonWindow } from './season';
import type { AnswerCard, Lang, PlotSummary, RuleCondition, SeasonWindow } from './types';

export const FALLBACK_ID = 'ask_officer';

/** True when every condition holds. An unknown key makes the rule not match. */
export function ruleMatches(cond: RuleCondition, s: PlotSummary, window: SeasonWindow): boolean {
  for (const [key, value] of Object.entries(cond) as [string, unknown][]) {
    // A non-numeric threshold gives NaN, and every comparison with NaN fails.
    const num = typeof value === 'number' ? value : Number.NaN;
    switch (key) {
      case 'dominant':
        if (s.dominant !== value) return false;
        break;
      case 'affected_gte':
        if (!(s.affected >= num)) return false;
        break;
      case 'affected_lte':
        if (!(s.affected <= num)) return false;
        break;
      case 'uncertain_gte':
        if (!(s.uncertain >= num)) return false;
        break;
      case 'distinct_problems_gte':
        if (!(s.distinctProblems >= num)) return false;
        break;
      case 'window':
        if (window !== value) return false;
        break;
      default:
        return false;
    }
  }
  return true;
}

export function getAnswer(id: string): AnswerCard {
  const entry = answerById(id) ?? answerById(FALLBACK_ID);
  if (!entry) {
    // Only reachable if answers.json lost ask_officer; the content tests guard this.
    return { id: FALLBACK_ID, severity: 'ask', text: {}, audio: {}, sources: [], assumption: true };
  }
  const audio: Partial<Record<Lang, string>> = {};
  for (const lang of Object.keys(entry.text) as Lang[]) audio[lang] = `/audio/${lang}/${entry.id}.mp3`;
  return {
    id: entry.id,
    severity: entry.severity,
    text: entry.text,
    notSure: entry.not_sure,
    audio,
    sources: entry.sources ?? [],
    assumption: entry.assumption,
    kind: entry.kind,
    reviewStatus: entry.review_status,
  };
}

export function decideForWindow(summary: PlotSummary, window: SeasonWindow): AnswerCard {
  const rule = RULES.find((r) => ruleMatches(r.if ?? {}, summary, window));
  return getAnswer(rule?.then ?? FALLBACK_ID);
}

export function decide(summary: PlotSummary, date: Date): AnswerCard {
  return decideForWindow(summary, seasonWindow(date));
}
